void updateOutputBufferAndDisplay(char input);
